#!/bin/bash
cut -d: -f1,7 /etc/passwd --output-delimiter='    '
