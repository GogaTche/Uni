#!/bin/bash
read -p 'enter first date: ' d1
read -p 'enter second date: ' d2
find -newerct $d1 ! -newerct $d2

