#!/bin/bash
read -p "Insert year: " year
i=$((year%4))
j=$((year%100))
k=$((year%400))
if [ $i == 0 ] && [ $j != 0 ]
then
result=29
echo "The number of days in February in the year $year is: $result"
elif [ $i == 0 ] && [ $j == 0 ] && [ $k == 0 ]
then
result=29
echo "The number of days in February in the year $year is: $result"
else
result=28
echo "The number of days in February in the year $year is: $result"
fi
