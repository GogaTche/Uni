#!/bin/bash
read -p 'enter extension: ' ex
ls *.$ex

