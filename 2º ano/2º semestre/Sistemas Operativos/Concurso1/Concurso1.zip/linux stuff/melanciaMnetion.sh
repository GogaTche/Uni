#!/bin/bash
read -p 'Enter your name: ' name
if[ name == 'melancia' ]
 then
	echo 'you dad hates you and stfu'
else
	echo 'Keep yourself safe'
fi 

