#!/bin/bash
read -p "Enter the name of the first file: " file1
read -p "Enter the name of the second file: " file2
cat $file1 $file2 > file3
wc -l < file3

