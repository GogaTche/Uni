#!/bin/bash
read -p "String que deseja procurar: " string
grep -l "$string" ./*

