#!/bin/bash
read -p "Insert number to do the multiplication table: " number
read -p "Insert the limit of the table: " limit
i=0
while [ $limit -ge $i ]
do
result=$((i*number))
echo "$i x $number = $result"
((i++))
done
