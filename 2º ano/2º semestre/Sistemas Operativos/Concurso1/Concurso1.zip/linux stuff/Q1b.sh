#!/bin/bash
read -p 'enter size: ' s
find ./* -size +"$s"c
