#!/bin/bash
read -p "write a number: " number
input=$number
result=1
while [ $number -gt 1 ]
do
result=$((result*$number))
number=$((number - 1))
done
echo "The factorial of $input is: $result"
