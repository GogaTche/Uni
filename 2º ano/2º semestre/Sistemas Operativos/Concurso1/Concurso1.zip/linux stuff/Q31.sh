#!/bin/bash
read -p "Extension you want to modify: " Ex1
read -p "Extension you want to Replace $Ex1 with: " Ex2
for file in *.$Ex1
do
mv "$file" "${file%.*}.$Ex2"
done
