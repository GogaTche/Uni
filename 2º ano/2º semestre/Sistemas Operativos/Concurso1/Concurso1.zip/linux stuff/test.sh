#!/bin/bash
if [ $1 -ge 9 ]
then
 echo "A"
else
 echo "NA"
fi
