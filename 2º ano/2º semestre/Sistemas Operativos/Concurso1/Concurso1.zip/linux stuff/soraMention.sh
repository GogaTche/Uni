#!/bin/bash
i=0
j=10000000
while [ $i -le $j ] 
do
echo "kys aborrece esrever"
((i++))
done

